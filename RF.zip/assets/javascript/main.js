    document.addEventListener('DOMContentLoaded', function() {
      // Mobile Menu Toggle
      const mobileMenuBtn = document.getElementById('mobile-menu-btn');
      const navLinks = document.getElementById('nav-links');
      
      mobileMenuBtn.addEventListener('click', function() {
        navLinks.classList.toggle('active');
        mobileMenuBtn.innerHTML = navLinks.classList.contains('active') ?
          '<i class="fas fa-times"></i>' : '<i class="fas fa-bars"></i>';
      });
      
      // Smooth Scroll for Navigation Links
      document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
          e.preventDefault();
          
          const targetId = this.getAttribute('href');
          if (targetId === '#') return;
          
          const targetElement = document.querySelector(targetId);
          if (targetElement) {
            window.scrollTo({
              top: targetElement.offsetTop - 80,
              behavior: 'smooth'
            });
            
            // Close mobile menu if open
            if (navLinks.classList.contains('active')) {
              navLinks.classList.remove('active');
              mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            }
          }
        });
      });
      
      // Header Scroll Effect
      window.addEventListener('scroll', function() {
        const header = document.querySelector('header');
        if (window.scrollY > 50) {
          header.classList.add('header-scrolled');
        } else {
          header.classList.remove('header-scrolled');
        }
      });
      
      // Testimonials Slider
      const testimonialSlides = document.querySelectorAll('.testimonial-slide');
      const dots = document.querySelectorAll('.dot');
      let currentSlide = 0;
      let intervalId;
      
      function showSlide(index) {
        testimonialSlides.forEach(slide => {
          slide.classList.remove('active');
        });
        dots.forEach(dot => {
          dot.classList.remove('active');
        });
        
        testimonialSlides[index].classList.add('active');
        dots[index].classList.add('active');
        currentSlide = index;
      }
      
      function nextSlide() {
        currentSlide = (currentSlide + 1) % testimonialSlides.length;
        showSlide(currentSlide);
      }
      
      // Initialize slider
      intervalId = setInterval(nextSlide, 5000);
      
      // Click on dots to navigate
      dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
          clearInterval(intervalId);
          showSlide(index);
          intervalId = setInterval(nextSlide, 5000);
        });
      });
      
      // FAQ Accordion
      const accordionItems = document.querySelectorAll('.accordion-item');
      
      accordionItems.forEach(item => {
        const header = item.querySelector('.accordion-header');
        const content = item.querySelector('.accordion-content');
        
        header.addEventListener('click', () => {
          // Toggle active class
          item.classList.toggle('active');
          
          // If active, set max-height to show content
          if (item.classList.contains('active')) {
            content.style.maxHeight = content.scrollHeight + "px";
          } else {
            content.style.maxHeight = null;
          }
          
          // Close other accordion items
          accordionItems.forEach(otherItem => {
            if (otherItem !== item && otherItem.classList.contains('active')) {
              otherItem.classList.remove('active');
              otherItem.querySelector('.accordion-content').style.maxHeight = null;
            }
          });
        });
      });
      
      // Pricing toggle (monthly/yearly)
      const pricingToggle = document.getElementById('pricing-toggle');
      const priceElements = document.querySelectorAll('.price');
      const monthlyPrices = ['$4.99', '$9.99', '$19.99'];
      const yearlyPrices = ['$3.99', '$7.99', '$15.99'];
      
      pricingToggle.addEventListener('change', function() {
        const isYearly = this.checked;
        
        priceElements.forEach((element, index) => {
          if (isYearly) {
            element.innerHTML = `${yearlyPrices[index]}<span>/mes</span>`;
          } else {
            element.innerHTML = `${monthlyPrices[index]}<span>/mes</span>`;
          }
        });
      });
      
      // Live Chat
      const liveChatBtn = document.getElementById('live-chat-btn');
      const chatWindow = document.getElementById('chat-window');
      const closeChat = document.getElementById('close-chat');
      const chatInput = document.getElementById('chat-input');
      const sendBtn = document.getElementById('send-btn');
      const chatBody = document.getElementById('chat-body');
      
      liveChatBtn.addEventListener('click', function() {
        chatWindow.classList.add('active');
      });
      
      closeChat.addEventListener('click', function() {
        chatWindow.classList.remove('active');
      });
      
      function sendMessage() {
        const message = chatInput.value.trim();
        
        if (message) {
          // Create user message
          const userMessageDiv = document.createElement('div');
          userMessageDiv.className = 'chat-message';
          userMessageDiv.innerHTML = `
            <div class="chat-bubble user">
              <p>${message}</p>
            </div>
          `;
          chatBody.appendChild(userMessageDiv);
          
          // Clear input
          chatInput.value = '';
          
          // Auto-scroll to bottom
          chatBody.scrollTop = chatBody.scrollHeight;
          
          // Simulate agent response after delay
          setTimeout(() => {
            const agentMessageDiv = document.createElement('div');
            agentMessageDiv.className = 'chat-message';
            agentMessageDiv.innerHTML = `
              <div class="chat-bubble agent">
                <p>Esta es una demo del chat. En la versión completa, conectaremos con un agente real. ¿Tienes alguna otra pregunta sobre nuestros planes de hosting?</p>
              </div>
            `;
            chatBody.appendChild(agentMessageDiv);
            
            // Auto-scroll to bottom again
            chatBody.scrollTop = chatBody.scrollHeight;
          }, 1000);
        }
      }
      
      sendBtn.addEventListener('click', sendMessage);
      
      chatInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
          sendMessage();
        }
      });
      
      // Contact Form Validation
      const contactForm = document.getElementById('contact-form');
      const formSuccess = document.getElementById('form-success');
      
      contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        let isValid = true;
        
        // Validate name
        const name = document.getElementById('name');
        const nameError = document.getElementById('name-error');
        
        if (name.value.trim() === '') {
          name.style.borderColor = 'var(--red-primary)';
          nameError.style.display = 'block';
          isValid = false;
        } else {
          name.style.borderColor = '';
          nameError.style.display = 'none';
        }
        
        // Validate email
        const email = document.getElementById('email');
        const emailError = document.getElementById('email-error');
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        
        if (!emailRegex.test(email.value.trim())) {
          email.style.borderColor = 'var(--red-primary)';
          emailError.style.display = 'block';
          isValid = false;
        } else {
          email.style.borderColor = '';
          emailError.style.display = 'none';
        }
        
        // Validate subject
        const subject = document.getElementById('subject');
        const subjectError = document.getElementById('subject-error');
        
        if (subject.value.trim() === '') {
          subject.style.borderColor = 'var(--red-primary)';
          subjectError.style.display = 'block';
          isValid = false;
        } else {
          subject.style.borderColor = '';
          subjectError.style.display = 'none';
        }
        
        // Validate message
        const message = document.getElementById('message');
        const messageError = document.getElementById('message-error');
        
        if (message.value.trim() === '') {
          message.style.borderColor = 'var(--red-primary)';
          messageError.style.display = 'block';
          isValid = false;
        } else {
          message.style.borderColor = '';
          messageError.style.display = 'none';
        }
        
        if (isValid) {
          // Show success message
          formSuccess.style.display = 'block';
          contactForm.reset();
          
          // Hide success message after 5 seconds
          setTimeout(() => {
            formSuccess.style.display = 'none';
          }, 5000);
        }
      });
    });